# 데스크톱 실행 패키지

이 폴더만 옮겨 A24 실측 기반 CPU/GPU 시뮬레이션과 스케줄러 PPO 학습을 실행할 수 있다. 휴대폰·Android Studio·ADB·APK·TFLite는 필요하지 않다. ZIP에는 자체 PPO의 terminal64 세 개가 포함된다. 기존 실험에서 우위가 입증된 정책은 아니며 학습량을 늘린다고 개선을 보장하지 않는다.

먼저 Python 3.11 환경에서 설치한다.

```powershell
python -m pip install numpy==2.4.6
python -m pip install --index-url https://download.pytorch.org/whl/cpu torch==2.11.0+cpu
python -B -X utf8 -m tools.d1_joint_amount_cli
```

마지막 명령은 source·모형·체크포인트·공유 RNG 검증만 한다. 추가 학습은 자동으로 시작하지 않는다.

64→128 연장 예시는 세 모델 각각64 추가, 총192학습/예정664환경이다. 아직 소비하지 않은 새 task·seed와 예산을 명시한다.

```powershell
python -B -X utf8 -m tools.d1_joint_amount_cli prepare --task amount128_a --target 128 --arrival-start 860010001 --confirm-seeds 860020101 860020102 860020103 860020104 --native-cap 700 --learning-cap 192 --active-minutes 60 --reserve-minutes 5
python -B -X utf8 -m tools.d1_joint_amount_cli run --task amount128_a
```

중지는 작업폴더의 `REQUEST_STOP` 빈파일로 요청한다. 현재 환경 실행이 끝난 경계에서 상태를 저장한다. 재개하려면 그 파일을 없애고 같은 `run --task` 명령을 실행한다. 완료 실험을 다시 등록하거나 소비한 예산을 초기화하지 않는다. 강제 종료와 정상 경계 중지는 다르며, 상태/소비가 맞지 않으면 안전하게 중단한다.

세 모델은 독립 초기화 seed와 공유 sampling RNG를 사용한다. 모델별 weights만이 아니라 세 actor/critic/Adam/승수·공유 RNG·다음 실행순서를 함께 저장한다. 현재 V1의 마스크·참조·목적을 바꾸면 같은 학습량 연장이 아니다.

[상세 이관 근거](docs/results/desktop_handoff_20261011/README.md) · [학습 연장 계약](docs/DESKTOP_JOINT_RL_AMOUNT_20261011.md) · [파일 SHA](bundle_manifest.json)
