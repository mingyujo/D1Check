package com.example.d1check

import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.view.WindowManager
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * D1Check v3
 *
 * - BatteryManager 전류값을 단위 변환 없이 current_raw로 기록한다.
 * - thermal headroom 전체 호출률을 약 1Hz로 제한한다.
 * - h0와 h60을 교대로 호출하므로 각 값은 약 2초마다 갱신된다.
 * - charge counter는 배터리 노후도가 아니라 현재 전하량 보조값이다.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var textView: TextView
    private val handler = Handler(Looper.getMainLooper())

    private var headroomNow = Float.NaN
    private var headroom60s = Float.NaN
    private var tick = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        textView = TextView(this).apply {
            textSize = 13f
            setPadding(32, 64, 32, 32)
        }
        setContentView(ScrollView(this).apply { addView(textView) })
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        handler.post(measurementLoop)
    }

    override fun onDestroy() {
        handler.removeCallbacks(measurementLoop)
        super.onDestroy()
    }

    private val measurementLoop = object : Runnable {
        override fun run() {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            val batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager

            if (tick % 2L == 0L) {
                headroomNow = powerManager.getThermalHeadroom(0)
            } else {
                headroom60s = powerManager.getThermalHeadroom(60)
            }

            val currentRaw = batteryManager.getIntProperty(
                BatteryManager.BATTERY_PROPERTY_CURRENT_NOW
            )
            val chargeCounterRaw = batteryManager.getIntProperty(
                BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER
            )
            val batteryIntent = registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val voltageMv = batteryIntent?.getIntExtra(
                BatteryManager.EXTRA_VOLTAGE, -1
            ) ?: -1
            val batteryTempC = (
                    batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -10
                    ) / 10.0
            val plugged = batteryIntent?.getIntExtra(
                BatteryManager.EXTRA_PLUGGED, -1
            ) ?: -1

            val currentValid = currentRaw != Int.MIN_VALUE
            val chargeCounterValid = chargeCounterRaw != Int.MIN_VALUE
            val verdict = when {
                !headroomNow.isNaN() -> "HEADROOM_OK"
                tick >= 15L -> "HEADROOM_UNSUPPORTED_OR_ERROR"
                else -> "HEADROOM_WARMUP"
            }

            val logLine = listOf(
                "t=${tick}s",
                "headroom_now=$headroomNow",
                "headroom_60s=$headroom60s",
                "thermal_status=${powerManager.currentThermalStatus}",
                "current_raw=$currentRaw",
                "current_valid=$currentValid",
                "voltage_mV=$voltageMv",
                "battery_temp_C=$batteryTempC",
                "charge_counter_raw=$chargeCounterRaw",
                "charge_valid=$chargeCounterValid",
                "plugged=$plugged",
                "verdict=$verdict"
            ).joinToString(" | ")

            val displayText = logLine.replace(" | ", "\n") + "\n\n"
            textView.text = displayText + textView.text.toString().take(3500)
            Log.i("D1CHECK", logLine)

            tick++
            handler.postDelayed(this, 1000L)
        }
    }
}
