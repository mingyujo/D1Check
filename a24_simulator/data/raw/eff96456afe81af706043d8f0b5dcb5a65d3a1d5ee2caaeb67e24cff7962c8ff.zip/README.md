# A24 C10 / CONFIRM / R02CONFIRM03

공개 스냅샷 2026-10-15T17:23:26.948188+00:00. 정상 완료 2/2군. 실패·중지·미시도·진행 중은 BLOCK_STATUS.json과 attempts.csv에 그대로 남겼다.

raw/와 supplemental_same_run_raw/는 회수한 원자료의 원래 바이트다. 후자는 실패 원실행의 추가 읽기 전용 회수이며 정상 결과로 승격하지 않았다. public_manifests/는 식별 정보를 제외한 파생 설정이다. 파일별 SHA는 FILE_SHA256.json에 있다.

모델·APK·승인 이미지·키·개인 식별 설정과 전체 시스템로그는 포함하지 않는다. 모델/입력/텐서의 SHA와 출처는 public_manifests/ 및 공유폴더 sources/에서 확인한다. 검증된 J·표면온도·정책 채택 결과가 아니다.
